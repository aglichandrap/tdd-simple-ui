import './App.css'

export const App = () => {
  return (
    <main>
      <h1>TDD for Building UIs Demo</h1>
    </main>
  )
}
